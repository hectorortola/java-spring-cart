package com.onebox.hector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(HectorApplication.class, args);
	}

}
